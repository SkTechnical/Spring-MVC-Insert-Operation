package com.example.spring_web_controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebControllerYoutubeApplicationTests {

	@Test
	void contextLoads() {
	}

}
